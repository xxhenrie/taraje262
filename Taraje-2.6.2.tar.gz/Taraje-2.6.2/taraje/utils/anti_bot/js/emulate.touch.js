Object.defineProperty(navigator, 'maxTouchPoints', {
    get: () => 1
});
