--[============================================================[

  `RW`  = Read-Write (editable) variable
  `RO`  = Read-Only variable
  `>>>` = Example usage

**** variables

  ** Stake
      apikey             : string : RW  [required]

      mirror             : string : RW  [optional]
      cookie             : string : RW  [optional]
      user_agent         : string : RW  [optional]

  basebet            : float  : RW  [required]
  currency           : string : RW  [required]
  nextbet            : float  : RW  [required]
  target             :        : RW  [required]
                    ** float (single target),
                       >>> target = 37.89
                    ** table (random target between low-high),
                       >>> target = {low = 37, high = 37.89}
                    ** or, you can retrieve them using dot (.) notation.
                       >>> target.low
                       >>> target.high
                    ** minimum target: 1.00000000000001

               **NOTE: you must fill this variable with MULTIPLIER-TARGET, not WIN-CHANCE!!
                       ** If you want to use chance, I have made an example function to convert chance to target. You can find it below.

  protect_profile    : bool   : RW  [optional, default: false]
                    ** Hide your username, email, and VIP-Stats

  maxbet             : float  : RW  [optional]
  replay             : bool   : RW  [optional, default: false]
  resetIfLose        : float  : RW  [optional]
  resetIfProfit      : float  : RW  [optional]
  resetIfLoseStreak  : int    : RW  [optional]
  resetIfWinStreak   : int    : RW  [optional]
  targetBalance      : float  : RW  [optional]
  targetLose         : float  : RW  [optional]
  targetProfit       : float  : RW  [optional]

  balance            : float  : RO
  bets               : int    : RO
  broker             : string : RO : broker-name
  currentstreak      : int    : RO
                    ** currentstreak is a positive or negative integer. Will be positive when you `win` and negative when you `lose`.

  lastBet            : table  : RO
                    ** This is an object containing more details about the previous bet, including:
                       ** amount    : float  :
                       ** target    : float  :
                       ** profit    : float  : profit for the last bet made. This is not the total profit (betting 1 unit at x2 payout, when winning, profit will show 1 (returned = 2), when losing, profit will show -1).
                       ** result    : float  : lucky number
                       ** nonce     : int    :
                    ** you can retrieve them using dot (.) notation.
                       >>> lastBet.target

  losses             : int    : RO
  previousbet        : float  : RO
  profit             : float  : RO
  win                : bool   : RO
  wins               : int    : RO

  isFirstGreen              : bool : RO
  isFirstRed                : bool : RO
  isMaxBetReached           : bool : RO
  isResetWinStreakReached   : bool : RO
  isResetLoseStreakReached  : bool : RO
  isResetProfitReached      : bool : RO
  isResetLossReached        : bool : RO

  seedChanged               : bool : RO : return `true` if seed changed succesfully, otherwise `false`


**** functions

  dobet()              : your logic here
  stop()               : kill the bot
  resetseed(seed)      :

             ** resetseed require `seed` parameter, if seed is not specified, the bot will automatically generate a random seed for you.


--]============================================================]

--[=============[
     EXAMPLE!!
--]=============]


function chance_to_target(chance)
    if broker:lower() == "stake" then
        div = 99
    elseif broker:lower() == "pasino" then
        div = 97
    end
    return tonumber(string.format("%.2f", (div/chance)))
end
-- call this function with `chance_to_target(your_chance)`. e.g:
-- target = chance_to_target(3.78)

function fibonacci(level)
    local _start, _next = 0, 1
    if level <= 0 then
        return basebet
    end
    for i = 1, level do
        _start, _next = _next, _start + _next
    end
    return _start * basebet
end


apikey = ""

basebet = 0.0000378
currency = "trx"
nextbet = basebet

target = chance_to_target(95)
-- target = {low=chance_to_target(90), high=chance_to_target(95)}
-- target.low = chance_to_target(90)
-- target.high = chance_to_target(95)

resetIfProfit = 0.00000001
-- targetProfit = 0.1
targetBalance = 200000

-- custom requirement variables
fibonacciLevel = 1
incLevel = false


function dobet()
    if win then
        if currentstreak <= -5 then
            fibonacciLevel = fibonacciLevel - 5
        end
        if currentstreak >= 2 then
            target = chance_to_target(90)
            incLevel = false
        end
        if currentstreak >= 19 and currentstreak <= 27 then
            incLevel = true
        else
            incLevel = false
        end
        if incLevel then
            fibonacciLevel = fibonacciLevel + 1
        else
            if fibonacciLevel < 2 then
                fibonacciLevel = 1
            else
                fibonacciLevel = fibonacciLevel - 1
            end
        end
        nextbet = fibonacci(fibonacciLevel)
    else
        -- jump
        if currentstreak == -5 then
            fibonacciLevel = fibonacciLevel + 5
        else
            fibonacciLevel = fibonacciLevel + 1
        end
        if isFirstRed then
            target = {low=chance_to_target(60), high=chance_to_target(70)}
        else
            target = lastBet.target
        end
        nextbet = fibonacci(fibonacciLevel)
    end

    if currentstreak <= -37 then
        if (broker:lower() == "stake") or (broker:lower() == "wolf") then
            resetseed("myClientSeed378")
            -- you also can use this function just like:
            -- >> resetseed()
        elseif broker:lower() == "pasino" then
            resetseed()
        end
    end

    if isResetProfitReached then
        nextbet = basebet
        target = {low=chance_to_target(90), high=chance_to_target(95)}
        incLevel = false
        fibonacciLevel = 1
    end
end
