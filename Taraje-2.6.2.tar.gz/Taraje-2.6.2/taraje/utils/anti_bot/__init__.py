# -*- coding: utf-8 -*-
"""
    :Author: ampasmanusa (bancetzLaut) <0.ampasmanusa@gmail.com>
    :Created: 2022-10-14T11:59:57+07:00
    :Updated: 2023-11-12T03:10:26+07:00
    :Version: 0.2.8
    :Description: Taraje's Anti-Bot handler.

    ..NOTE:: Version 0.1.0 of this module can be found at taraje-2.0.0.

    """
